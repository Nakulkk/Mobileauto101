// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

package org.openqa.selenium.remote;

import java.util.function.Consumer;
import org.openqa.selenium.Beta;
import org.openqa.selenium.bidi.log.ConsoleLogEntry;
import org.openqa.selenium.bidi.log.JavascriptLogEntry;
import org.openqa.selenium.bidi.script.RemoteValue;

@Beta
public interface Script {

  String addConsoleMessageHandler(Consumer<ConsoleLogEntry> consumer);

  void removeConsoleMessageHandler(String id);

  String addJavaScriptErrorHandler(Consumer<JavascriptLogEntry> consumer);

  void removeJavaScriptErrorHandler(String id);

  String addDomMutationHandler(Consumer<DomMutation> event);

  void removeDomMutationHandler(String id);

  String pin(String script);

  void unpin(String id);

  RemoteValue execute(String script, Object... args);
}
